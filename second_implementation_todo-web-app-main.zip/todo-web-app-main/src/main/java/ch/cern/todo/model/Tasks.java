package ch.cern.todo.model;

import javax.persistence.*;

//responsible for creating and maintaining table tasks

@Entity  //this class is persistent Java class
@Table(name = "tasks")
public class Tasks {

    @Id //annotation that it is a primary key
    @GeneratedValue(strategy = GenerationType.AUTO) //id will increase automatically
    private long task_id;

    @Column(columnDefinition="VARCHAR2(100)", name = "task_name")
    private String task_name;

    @Column(columnDefinition="VARCHAR2(500)",name = "task_description")
    private String task_description;

    @Column(columnDefinition="TIMESTAMP",name = "deadline") //timestamp at the end
    private String deadline;

    @Column(columnDefinition="VARCHAR2(100)",name = "category_name")
    private String category_name;

    @Column(columnDefinition="VARCHAR2(500)",name = "category_description")
    private String category_description;

    public Tasks(String task_name, String task_description, String deadline,
                 String category_name, String category_description){

        this.task_name=task_name;
        this.task_description=task_description;
        this.deadline=deadline;
        this.category_name=category_name;
        this.category_description=category_description;
    }

    public long getId(){
        return task_id;
    }
    public String getTaskName(){
        return task_name;
    }
    public void setTaskName(String task_name){
        this.task_name=task_name;
    }
    public String getTaskDescription(){
        return task_description;
    }
    public void setTaskDescription(String task_description){
        this.task_description = task_description;
    }
    public String getDeadline(){
        return deadline;
    }
    public void setDeadline(String deadline){
        this.deadline=deadline;
    }
    public String getCategoryName(){
        return category_name;
    }
    public void setCategoryName(String category_name){
        this.category_name=category_name;
    }
    public String getCategoryDescription(){
        return category_description;
    }
    public void setCategoryDescription(String category_description){
        this.category_description=category_description;
    }

    @Override
    public String toString(){
        return "Task [id="+task_id+", name="+task_name+", description="+task_description+"]";
    }

}
