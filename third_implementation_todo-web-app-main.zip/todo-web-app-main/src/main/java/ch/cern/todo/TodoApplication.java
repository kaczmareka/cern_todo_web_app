package ch.cern.todo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;

@SpringBootApplication
public class TodoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodoApplication.class, args);
	}

	@EventListener(ApplicationReadyEvent.class)
	public void printSomethingAfterStartup() {
		System.out.println("TodoApplication started");
	}

//	my to do list:
	//tests - czy to z javy mam odpytywać tamto api i sprawdzać co się tam dzieje?
	//add second db table - próba 2


}
